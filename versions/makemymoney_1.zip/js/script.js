$(document).ready(function(){
	$("#loan-link").on("mouseenter", function(){
		TweenMax.to($("#loan-sub-menu"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
		TweenMax.to($("#cal-sub-menu"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
	});
	$(".menu-link").on("click", function(){
		TweenMax.to($(".sidebar"), 0.5, {ease:Back.easeOut, right:0});
		TweenMax.to($(".sidebar-overlay"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
	});
	$(".signupBtn").on("click", function(){
		TweenMax.to($(".loginWrap"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
	});
	$(".closeReg").on("click", function(){
		TweenMax.to($(".loginWrap"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
	});
	$(".product-tab").on("click", function(){
		$(this).removeClass("inactive");
		$(this).addClass("active");
		$(this).siblings().addClass("inactive");
		$(this).siblings().removeClass("active");
		if($(this).hasClass("quick-link")){
			TweenMax.set($(this).parent().siblings(".quick"),{css:{display:"block"}}); 
			TweenMax.to($(this).parent().siblings(".quick"), 0.5, {ease:Back.easeOut, opacity:1});
			TweenMax.set($(this).parent().siblings(".custom"),{css:{display:"none"}}); 
			TweenMax.to($(this).parent().siblings(".custom"), 0.5, {ease:Back.easeOut, opacity:0});
		}else{
			TweenMax.set($(this).parent().siblings(".custom"),{css:{display:"block"}}); 
			TweenMax.to($(this).parent().siblings(".custom"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
			TweenMax.set($(this).parent().siblings(".quick"),{css:{display:"none"}}); 
			TweenMax.to($(this).parent().siblings(".quick"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
		}
	});
	/*$(".quick-link").on("click", function(){
		$(this).addClass("active");
		$(".custom-link").removeClass("inactive");
		$(".custom-link").addClass("inactive");
		if($(this).hasClass("inactive")){
			TweenMax.to($(this).parent().siblings(".quick"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
			TweenMax.to($(this).parent().siblings(".custom"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
		}
	});
	$(".custom-link").on("click", function(){
		if($(this).hasClass("inactive")){
			$(this).removeClass("inactive");
			$(this).addClass("active");
			$(".quick-link").removeClass("inactive");
			$(".quick-link").addClass("inactive");
			TweenMax.to($(this).parent().siblings(".custom"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
			TweenMax.to($(this).parent().siblings(".quick"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
		}
	});*/
	$(".sidebar-overlay").on("click", function(){
		TweenMax.to($(".sidebar"), 0.5, {ease:Back.easeIn, right:"-25%"});
		TweenMax.to($(".sidebar-overlay"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
	});
	$("#cal-link").on("mouseenter", function(){
		TweenMax.to($("#loan-sub-menu"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
		TweenMax.to($("#cal-sub-menu"), 0.5, {ease:Back.easeOut, display:"block", opacity:1});
	});
	$(".nav-link-submenu").on("mouseleave", function(){
		TweenMax.to($("#cal-sub-menu"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
		TweenMax.to($("#loan-sub-menu"), 0.5, {ease:Back.easeOut, display:"none", opacity:0});
	});

	function tlComplete(){
		tl.restart();
	};

	var tl = new TimelineMax({
		onComplete:tlComplete
	});
	tl.insert( TweenMax.staggerTo(".news-item", 5, {	
		delay:2,
    	top:"-250px",
    	ease: SlowMo.ease.config(0.7, 0.7, false)
    }, 5) );

});